print("Python has three numeric types: int, float, and complex")
python3 <numeric-data.p